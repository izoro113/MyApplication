package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
class homepage : AppCompatActivity() {

    private lateinit var buttonwalp: Button
    private lateinit var buttonchar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.homepage)
        init()
    }


    private fun init() {

        buttonwalp = findViewById(R.id.walp)
        buttonchar = findViewById(R.id.wiki)
        listeners()
    }


    private fun listeners() {
        buttonwalp.setOnClickListener {
            startActivity(Intent(this, wallpaper::class.java))
        }
        buttonchar.setOnClickListener {
            startActivity(Intent(this, characters::class.java))


        }
    }
}
