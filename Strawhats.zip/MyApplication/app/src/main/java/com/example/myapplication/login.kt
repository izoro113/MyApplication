package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class login : AppCompatActivity() {
    private lateinit var editTextEmail: EditText
    private lateinit var editPassword: EditText
    private lateinit var buttonLog: Button
    private lateinit var buttonRegister: Button
    private lateinit var buttonPassword: Button




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)
        init()
    }

    private fun init(){
        editTextEmail=findViewById(R.id.loginName)
        editPassword=findViewById(R.id.loginPassword)
        buttonLog=findViewById(R.id.logbutton)
        buttonRegister=findViewById(R.id.logbutton2)
        buttonPassword=findViewById(R.id.logbutton3)
        listeners()

    }
    private fun listeners(){

        buttonLog.setOnClickListener{
            val email = editTextEmail.text.toString()
            val passwords=editPassword.text.toString()
            if(email.isEmpty() || passwords.isEmpty()){
                Toast.makeText(this, "Empty!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            startActivity(Intent(this,homepage::class.java))

            FirebaseAuth.getInstance()
                .signInWithEmailAndPassword(email,passwords)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful){
                        goToHome()
                } else {
                        Toast.makeText(this, "EROOR!!", Toast.LENGTH_SHORT).show()
                    }
        }

        }

        buttonRegister.setOnClickListener{
            startActivity(Intent(this,registration::class.java))
        }
        buttonPassword.setOnClickListener{
            startActivity(Intent(this,password::class.java))


        }


    }
    private fun goToHome(){
        startActivity(Intent(this,homepage::class.java))

    }

    }

