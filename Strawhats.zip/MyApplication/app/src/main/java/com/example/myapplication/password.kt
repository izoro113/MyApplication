package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class password : AppCompatActivity() {

    private lateinit var buttoncont: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.password)
        init()
    }


    private fun init() {

        buttoncont = findViewById(R.id.changePasswordButton)

        listeners()
    }


    private fun listeners() {
        buttoncont.setOnClickListener {
            startActivity(Intent(this, changePassword::class.java))
        }

    }
}

